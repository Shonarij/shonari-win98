
# 💾 Shonari Windows98 Resume

A retro Windows 98-inspired resume page. Designed to be deployed on MyWeb10 or GitHub Pages.

## How to Use
1. Open the `index.html` in your browser to preview.
2. Upload to [MyWeb10](https://myweb10.com) or deploy using GitHub Pages.

## Includes:
- index.html — Main landing page
- config.json — Metadata for MyWeb10
- README.md — Project overview
